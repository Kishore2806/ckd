from flask import Flask,render_template,redirect



app=Flask(__name__)


@app.route("/")
def index():
    return render_template('login.html')

    '''return redirect(url_for('members'), 404)'''

@app.route("/predict",methods=['GET', 'POST'])
def next():
    return render_template('predict.html')

@app.route("/", methods=['GET', 'POST'])
def result1():
    return render_template('.html')

'''@app.route("/predict", methods=['GET', 'POST'])
def predict():
    return render_template('predict.html')'''



if __name__=='__main__':
    app.run(debug=True)